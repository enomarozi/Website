<!DOCTYPE html>
<html>
<head>
	<title>Website Sekolah</title>
	<link rel="stylesheet" href="styles/index.css">
</head>
<body>
<main>
	<div>
		<form method="post" action="guru.php">
			<h1>Login</h1>
			<input type="text" name="ID" placeholder="NISN/NIP">
			<input type="password" name="password" placeholder="Password">
			<input type="submit" name="submit" value="Submit">
			<h5>Forgot Password ? Please Contact your Admin Support</h5>
		</form>
		<?php
		$ID = $_POST['ID'];
		$pass = $_POST['password'];
		if(isset($ID) && isset($pass))
		{
			echo "<h3>OK</h3>";
		}
		else if(!isset($ID) || (!isset($pass))) {		
			echo "<h3>Ups Your ID or Password Incorrect!!</h3>";
		}
		?>
	</div>
</main>
</body>
</html>