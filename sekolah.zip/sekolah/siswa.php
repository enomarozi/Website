<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="styles/halaman.css">
	<link rel="stylesheet" href="styles/siswa.css">
	<title>Web Sekolah</title>
</head>
<body>
<header>
	<div class='header-button'>
		<div class='grid-header'>
			<img class='grid-header-item' src="images/Logo.png"  width="120%" height="100%">
			<div  class='grid-header-item'>
				<h3 class='SMA'>SMK SYADAM BOJONGGEDE</h3>	
				<h3 class='alamat'>Jl. Manunggal, Kec. Tajur Halang, Kabupaten Bogor, Jawa Barat</h3>
			</div>
			<button class='grid-header-item' type="button">Logout</button>
		</div>
	</div>
</header>
</body>
<main>
	<div class='profil'>
		<img src="images/martin.jpg" width="114" height="152" class='center'>
		<div class='grid-profil'>
			<h5 class='grid-profile-item'>Nama</h5> 
			<h5 class='grid-profile-item'>:</h5> 
			<h5 class='grid-profile-item'>Eno Marozi</h5>
			<h5 class='grid-profile-item'>NISN</h5> 
			<h5 class='grid-profile-item'>:</h5> 
			<h5 class='grid-profile-item'>1234567890</h5>
			<h5 class='grid-profile-item'>Jurusan</h5> 
			<h5 class='grid-profile-item'>:</h5> 
			<h5 class='grid-profile-item'>Komputer</h5>
		</div>
	</div>
	<div class='content'>
		<form class='grid-content' method="POST">
			<h4 class='grid-item'>Jurusan</h4>
			<h4 class='grid-item'>:</h4>
			<select class='grid-item'>
				<option>Teknik Mesin</option>
				<option>Elektronika</option>
				<option>Parawisata & Perhotelan</option>
				<option>Teknik Sipil</option>
			</select>
			<h4 class='grid-item'>Nama Guru</h4>
			<h4 class='grid-item'>:</h4>
			<select class='grid-item'>
				<option>Asra, Sp.d</option>
				<option>Yanti, Sp.d</option>
				<option>Uli, Sp.d</option>
				<option>Ika, Sp.d</option>
			</select>
			<h4 class='grid-item'>Mata pelajaran</h4>
			<h4 class='grid-item'>:</h4>
			<select class='grid-item'>
				<option>Matematika</option>
				<option>Biologi</option>
				<option>Fisika</option>
			</select>
			<h4 class='grid-item' style="font-size:0px">:</h4>	
			<h4 class='grid-item' style="font-size:0px">:</h4>
			<input type="Submit" name="submit" value="Submit" class='grid-item'>
		</form>
		<?php
		if(isset($_POST['submit']))
		{
			echo "<h6>Selamat Belajar</h6>";
		}
		?>
	</div>
</main>

<footer>
	<div>
		<h2>Copyright &copy;2022 By Tugas Akhir Sistem Informasi</h2>
	</div>
</footer>
</html>